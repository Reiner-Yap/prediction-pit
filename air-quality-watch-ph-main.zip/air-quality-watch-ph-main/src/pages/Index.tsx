import { useState, useEffect, useCallback } from 'react';
import { TitleBox } from '@/components/dashboard/TitleBox';
import { ControlsBox } from '@/components/dashboard/ControlsBox';
import { PredictionDisplay } from '@/components/dashboard/PredictionDisplay';
import { TimeSeriesChart } from '@/components/dashboard/TimeSeriesChart';
import { CityMap } from '@/components/dashboard/CityMap';
import { MeasurementsTable } from '@/components/dashboard/MeasurementsTable';
import { StatsCards } from '@/components/dashboard/StatsCards';
import { getAllCities, getCityData, getPrediction } from '@/data/mockData';
import { City, Prediction, TimeSeriesDataPoint, Measurement } from '@/types/airQuality';
import { toast } from '@/hooks/use-toast';
import { Helmet } from 'react-helmet-async';

export default function Index() {
  const [cities, setCities] = useState<City[]>([]);
  const [selectedCityId, setSelectedCityId] = useState<string>('');
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [timeSeries, setTimeSeries] = useState<TimeSeriesDataPoint[]>([]);
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Load cities on mount
  useEffect(() => {
    const loadedCities = getAllCities();
    setCities(loadedCities);
    if (loadedCities.length > 0) {
      setSelectedCityId(loadedCities[0].id);
    }
  }, []);

  // Load city data when selection changes
  useEffect(() => {
    if (selectedCityId) {
      const data = getCityData(selectedCityId);
      setTimeSeries(data.timeSeries);
      setMeasurements(data.measurements);
      setPrediction(null); // Reset prediction when city changes
    }
  }, [selectedCityId]);

  const handleCityChange = useCallback((cityId: string) => {
    setSelectedCityId(cityId);
    const city = cities.find(c => c.id === cityId);
    if (city) {
      toast({
        title: 'City Selected',
        description: `Now viewing data for ${city.name}`,
      });
    }
  }, [cities]);

  const handleGeneratePrediction = useCallback(async () => {
    if (!selectedCityId) return;

    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const newPrediction = getPrediction(selectedCityId);
    setPrediction(newPrediction);
    setIsLoading(false);

    const city = cities.find(c => c.id === selectedCityId);
    toast({
      title: 'Prediction Generated',
      description: `Air quality in ${city?.name || 'selected city'} is ${newPrediction.status}`,
    });
  }, [selectedCityId, cities]);

  const handleRefreshCities = useCallback(async () => {
    setIsRefreshing(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const refreshedCities = getAllCities();
    setCities(refreshedCities);
    setIsRefreshing(false);

    toast({
      title: 'Cities Refreshed',
      description: `${refreshedCities.length} cities loaded successfully`,
    });
  }, []);

  const selectedCity = cities.find(c => c.id === selectedCityId);

  return (
    <>
      <Helmet>
        <title>Philippines Air Pollution Risk Assessment | Air Quality Monitoring</title>
        <meta name="description" content="Real-time air quality monitoring and health risk prediction for major Philippine cities using machine learning. Monitor PM2.5, NO₂ levels and get AI-powered predictions." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <main className="container mx-auto px-4 py-6 space-y-6 max-w-7xl">
          {/* Title Box */}
          <section className="animate-fade-in" style={{ animationDelay: '0ms' }}>
            <TitleBox />
          </section>

          {/* Controls and Prediction Row */}
          <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 animate-slide-up" style={{ animationDelay: '100ms' }}>
              <ControlsBox
                cities={cities}
                selectedCityId={selectedCityId}
                onCityChange={handleCityChange}
                onGeneratePrediction={handleGeneratePrediction}
                onRefreshCities={handleRefreshCities}
                isLoading={isLoading}
                isRefreshing={isRefreshing}
              />
            </div>
            <div className="lg:col-span-2 animate-slide-up" style={{ animationDelay: '200ms' }}>
              <PredictionDisplay
                prediction={prediction}
                cityName={selectedCity?.name || ''}
              />
            </div>
          </section>

          {/* Stats Cards */}
          {timeSeries.length > 0 && (
            <section className="animate-slide-up" style={{ animationDelay: '300ms' }}>
              <StatsCards data={timeSeries} />
            </section>
          )}

          {/* Charts and Map Row */}
          <section className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3 animate-slide-up" style={{ animationDelay: '400ms' }}>
              <TimeSeriesChart
                data={timeSeries}
                cityName={selectedCity?.name || ''}
              />
            </div>
            <div className="lg:col-span-1 animate-slide-up" style={{ animationDelay: '500ms' }}>
              {selectedCity && (
                <CityMap
                  city={selectedCity}
                  status={prediction?.status}
                />
              )}
            </div>
          </section>

          {/* Measurements Table */}
          <section className="animate-slide-up" style={{ animationDelay: '600ms' }}>
            <MeasurementsTable
              measurements={measurements}
              cityName={selectedCity?.name || ''}
            />
          </section>

          {/* Footer */}
          <footer className="pt-8 pb-4 border-t border-border animate-fade-in" style={{ animationDelay: '700ms' }}>
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
              <div>
                Data sources: DENR-EMB, PAGASA, Regional Monitoring Stations
              </div>
              <div className="flex items-center gap-4">
                <span>Model: SVM Classifier v1.2.0</span>
                <span>•</span>
                <span>Last sync: {new Date().toLocaleString()}</span>
              </div>
            </div>
          </footer>
        </main>
      </div>
    </>
  );
}
